<!-- Header Include File -->
<?php include 'header.php'; ?>
<!-- Header Include File end -->

<!-- Breadcumb Section Start -->
<section class="breadcumb-wrapper">
		<div class="container">
			<div class="row">
				<div class="col-12">
					<h2>Why Choose Us</h2>
				</div>
			</div>
		</div>
</section>
<!-- Breadcumb Section End -->


<!-- About Section --> 
<section class="section-padding">
	<div class="container">
		<div class="row">
			<div class="col-12 mb-4 mb-md-5">
				<div class="section-title text-center">
					<h3>Welcome to</h3>
					<h1>GRANITE TOPS  <span>LTD</span></h1>
				</div>
			</div>
			<div class="col-12 col-md-7 col-lg-6 order-md-2 pl-lg-5 d-flex align-items-center">
					<p class="descripton">Granite Tops is a premium Granite company that produces, processes, manufactures and exports Granite products. We are proud of our product range including high quality Kitchen Bench Tops, Vanity Tops, Tiles, Fire places. We have over 30 colours of Granite to choose from and cater for the needs of all projects ranging from small residential to large commercial projects.<br><br>

					Engineered Stone kitchen counter tops are becoming a very popular choice in today's kitchen and provide many advantages.<br><br>
					
					Engineered Stone kitchen counter tops are becoming a very popular choice in today's kitchen and provide many advantages.</p>
			</div>
			<div class="col-12 col-md-5 col-lg-6 order-md-1 mt-4 mt-md-0 d-flex align-items-center">
			  <img src="assets/images/aboutus-img.jpg" class="img-fluid d-block mx-auto" alt="Granite Tops Ltd">
			</div>			
		</div>
		
		<div class="row mt-4 mt-md-5">
		   <div class="col-12">
			  <div class="d-flex justify-content-between flex-wrap flex-reverse">
				 <div id="coloum-1" class="coloum-grid">
					<div class="so-panel">
					   <div class="shadow-box overlap-right">
						<p class="descripton">
							Our state of the art processing units are equipped with sophisticated imported machinery and totally integrated facilities right from the selection of raw material to the exquisite designing, cutting, polishing and finishing, ensuring perfection in every product that carries the Granite Tops stamp.<br><br>
							Highly motivated staff along with a dedicated team of Management functions in tandem to produce best quality products. Complete customer satisfaction is the rule which we are strictly committed to.<br><br> Our commitment begins with understanding the customer's needs and requirements and make sure the final product is what you wanted. Focusing our skills on maintaining right time schedules, total concentration on delivering quality products without delay, has made the company earn legendary fame in no time.
						</p>
					   </div>
					</div>
				 </div>
				 <div id="coloum-2" class="coloum-grid">
					<div class="so-panel">
						<img src="assets/images/aboutus-img1.jpg" class="img-fluid d-block mx-auto mt-lg-4" width="570" height="620" alt="Granite Tops Ltd">					   
					</div>
				 </div>
			  </div>
		   </div>
		</div>
	</div>
</section>
<!-- About Section End --> 


<!-- Footer Include File -->
<?php include 'footer.php'; ?>
<!-- Footer Include File end -->