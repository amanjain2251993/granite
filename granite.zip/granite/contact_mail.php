<?php

	$name = $_POST["userName"];
	$email = $_POST["userEmail"];
	$phone = $_POST["subject"];
	$message = $_POST["content"];

	$conn = mysqli_connect("localhost", "root", "", "granite") or die("Connection Error: " . mysqli_error($conn));
	mysqli_query($conn, "INSERT INTO user (name, email,phone,message) VALUES ('" . $name. "', '" . $email. "','" . $phone. "','" . $message. "')");	
	$insert_id = mysqli_insert_id($conn);
	if(!empty($insert_id)) {
		$data = 'Contact Mail Sent.';
	echo json_encode($data); 	
	}
//uncomment for mail script.
	/* $toEmail = "admin@phppot_samples.com";
	
	$mailHeaders = "From: " . $_POST["userName"] . "<". $_POST["userEmail"] .">\r\n";
	if(mail($toEmail, $_POST["subject"], $_POST["content"], $mailHeaders)) {
	print "<p class='success'>Contact Mail Sent.</p>";
	} else {
	print "<p class='Error'>Problem in Sending Mail.</p>";
	}  */
	


?>
