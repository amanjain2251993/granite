<!-- Header Include File -->
<?php include 'header.php'; ?>
<!-- Header Include File end -->

<!-- Breadcumb Section Start -->
<section class="breadcumb-wrapper">
		<div class="container">
			<div class="row">
				<div class="col-12">
					<h2>Engineered Stone</h2>
				</div>
			</div>
		</div>
</section>
<!-- Breadcumb Section End -->

<!-- Product Section --> 
<section class="section-padding">
	<div class="container">
		<div class="row">
			<div class="col-12 mb-4 mb-md-5">
				<div class="section-title text-center">
					<h3>Welcome to Our Products</h3>
					<h1>Engineered Stone</h1>
				</div>
			</div>
			<div class="col-12 col-md-12 col-lg-6 order-lg-2 pl-lg-5">
				<p class="descripton">Engineered stone slabs are created from natures resplendent light and wind, transports natures beauty to all of your daily living spaces through natural and sophisticated textures and patterns. <br><br>

Engineered stone uses 93% hard quartz stone and the binding properties of polymer resins of 7%. Engineered stone is a significant improvement over natural stone in terms of moisture absorption and hardness. 
 </p>
			</div>
			<div class="col-12 col-md-12 col-lg-6 order-lg-1 mt-4 mt-lg-0">
				<div class="row">
					<div class="col-12 col-md-6 col-lg-6 gallery-coloum">
						<div class="gallery-wrap service-item">
							 <a href="assets/images/engineered-stones/1.jpg" data-lightbox="image-1">
								<div class="image-container">
								   <img src="assets/images/engineered-stones/1.jpg" class="img-fluid d-block mx-auto">
								</div>
							 </a>					 
						</div>
					</div>
					<div class="col-12 col-md-6 col-lg-6 gallery-coloum">
						<div class="gallery-wrap service-item">
							 <a href="assets/images/engineered-stones/2.jpg" data-lightbox="image-1">
								<div class="image-container">
								   <img src="assets/images/engineered-stones/2.jpg" class="img-fluid d-block mx-auto">
								</div>
							 </a>					 
						</div>
					</div>
					<div class="col-12 col-md-6 col-lg-6 gallery-coloum">
						<div class="gallery-wrap service-item">
							 <a href="assets/images/engineered-stones/3.jpg" data-lightbox="image-1">
								<div class="image-container">
								   <img src="assets/images/engineered-stones/3.jpg" class="img-fluid d-block mx-auto">
								</div>
							 </a>					 
						</div>
					</div>
					<div class="col-12 col-md-6 col-lg-6 gallery-coloum">
						<div class="gallery-wrap service-item">
							 <a href="assets/images/engineered-stones/4.jpg" data-lightbox="image-1">
								<div class="image-container">
								   <img src="assets/images/engineered-stones/4.jpg" class="img-fluid d-block mx-auto">
								</div>
							 </a>					 
						</div>
					</div>

				</div>
			</div>			
		</div>
		<div class="row mt-4">
			<div class="col-12">
				<p class="descripton">It has the natural beauty in terms of its external appearance of stone and its strength. Engineered stones are suited for kitchens, bathrooms, and other counter tops. Rest assured, we use the most environmental friendly methods for manufacturing quality quartz countertops.</p>
			</div>
		</div>
		<div class="row mt-4 mt-lg-5">
			<div class="col-12 col-md-6 col-lg-3 gallery-coloum">
				<div class="gallery-wrap service-item">
					 <a href="assets/images/engineered-stones/lenin-white.jpg" data-lightbox="image-1">
						<div class="image-container">
						   <img src="assets/images/engineered-stones/lenin-white.jpg" class="img-fluid d-block mx-auto">
						</div>						
					 </a>
					<div class="gallery-title">Lenin White</div>	
				</div>
			</div>
			<div class="col-12 col-md-6 col-lg-3 gallery-coloum">
				<div class="gallery-wrap service-item">
					 <a href="assets/images/engineered-stones/paradiso-quartz.jpg" data-lightbox="image-1">
						<div class="image-container">
						   <img src="assets/images/engineered-stones/paradiso-quartz.jpg" class="img-fluid d-block mx-auto">
						</div>
					 </a>
					<div class="gallery-title">Paradiso Quartz</div>		
				</div>
			</div>
			<div class="col-12 col-md-6 col-lg-3 gallery-coloum">
				<div class="gallery-wrap service-item">
					 <a href="assets/images/engineered-stones/platinum-black.jpg" data-lightbox="image-1">
						<div class="image-container">
						   <img src="assets/images/engineered-stones/platinum-black.jpg" class="img-fluid d-block mx-auto">
						</div>
					 </a>
					<div class="gallery-title">Platinum Black</div>		
				</div>
			</div>
			<div class="col-12 col-md-6 col-lg-3 gallery-coloum">
				<div class="gallery-wrap service-item">
					 <a href="assets/images/engineered-stones/platinum-dark-grey.jpg" data-lightbox="image-1">
						<div class="image-container">
						   <img src="assets/images/engineered-stones/platinum-dark-grey.jpg" class="img-fluid d-block mx-auto">
						</div>
					 </a>	
					<div class="gallery-title">Platinum Dark Grey</div>		
				</div>
			</div>
			<div class="col-12 col-md-6 col-lg-3 gallery-coloum">
				<div class="gallery-wrap service-item">
					 <a href="assets/images/engineered-stones/platinum-grey.jpg" data-lightbox="image-1">
						<div class="image-container">
						   <img src="assets/images/engineered-stones/platinum-grey.jpg" class="img-fluid d-block mx-auto">
						</div>
					 </a>	
					<div class="gallery-title">Platinum Grey</div>		
				</div>
			</div>
			<div class="col-12 col-md-6 col-lg-3 gallery-coloum">
				<div class="gallery-wrap service-item">
					 <a href="assets/images/engineered-stones/platinum-white.jpg" data-lightbox="image-1">
						<div class="image-container">
						   <img src="assets/images/engineered-stones/platinum-white.jpg" class="img-fluid d-block mx-auto">
						</div>
					 </a>
					<div class="gallery-title">Platinum White</div>		
				</div>
			</div>
			<div class="col-12 col-md-6 col-lg-3 gallery-coloum">
				<div class="gallery-wrap service-item">
					 <a href="assets/images/engineered-stones/silver-shot.jpg" data-lightbox="image-1">
						<div class="image-container">
						   <img src="assets/images/engineered-stones/silver-shot.jpg" class="img-fluid d-block mx-auto">
						</div>
					 </a>
					<div class="gallery-title">Silver Shot</div>		
				</div>
			</div>	
			<div class="col-12 col-md-6 col-lg-3 gallery-coloum">
				<div class="gallery-wrap service-item">
					 <a href="assets/images/engineered-stones/white-concrete.jpg" data-lightbox="image-1">
						<div class="image-container">
						   <img src="assets/images/engineered-stones/white-concrete.jpg" class="img-fluid d-block mx-auto">
						</div>
					 </a>
					<div class="gallery-title">White Concrete</div>		
				</div>
			</div>		
		</div>
	</div>
</section>
<!-- Product Section End --> 


<!-- Footer Include File -->
<?php include 'footer.php'; ?>
<!-- Footer Include File end -->