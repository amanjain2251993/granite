<!-- Header Include File -->
<?php include 'header.php'; ?>
<!-- Header Include File end -->

<!-- Breadcumb Section Start -->
<section class="breadcumb-wrapper">
		<div class="container">
			<div class="row">
				<div class="col-12">
					<h2>Marble</h2>
				</div>
			</div>
		</div>
</section>
<!-- Breadcumb Section End -->

<!-- Product Section --> 
<section class="section-padding">
	<div class="container">
		<div class="row">
			<div class="col-12 mb-4 mb-md-5">
				<div class="section-title text-center">
					<h3>Welcome to Our Products</h3>
					<h1>Marble</h1>
				</div>
			</div>
			<div class="col-12 col-md-12 col-lg-6 order-lg-2 pl-lg-5">
				<p class="descripton">Marble is a metamorphic rock that forms when limestone is subjected to the heat and pressure of metamorphism. It is composed primarily of the mineral calcite and usually contains other minerals, such as clay minerals, micas, quartz, pyrite, iron oxides, and graphite.<br><br>

Marble is the most porous choice for kitchen tops although this shouldn’t deter you. Marble has been used for thousands of years you just need to be aware of how to care for it to ensure its beauty will last for years to come.
 </p>
			</div>
			<div class="col-12 col-md-12 col-lg-6 order-lg-1 mt-4 mt-lg-0">
				<div class="row">
					<div class="col-12 col-md-6 col-lg-6 gallery-coloum">
						<div class="gallery-wrap service-item">
							 <a href="assets/images/marble/arabescato-sunset.jpg" data-lightbox="image-1">
								<div class="image-container">
								   <img src="assets/images/marble/arabescato-sunset.jpg" class="img-fluid d-block mx-auto">
								</div>
							 </a>					 
						</div>
					</div>
					<div class="col-12 col-md-6 col-lg-6 gallery-coloum">
						<div class="gallery-wrap service-item">
							 <a href="assets/images/marble/calacatta-lincoln.jpg" data-lightbox="image-1">
								<div class="image-container">
								   <img src="assets/images/marble/calacatta-lincoln.jpg" class="img-fluid d-block mx-auto">
								</div>
							 </a>					 
						</div>
					</div>
					<div class="col-12 col-md-6 col-lg-6 gallery-coloum">
						<div class="gallery-wrap service-item">
							 <a href="assets/images/marble/carrara.jpg" data-lightbox="image-1">
								<div class="image-container">
								   <img src="assets/images/marble/carrara.jpg" class="img-fluid d-block mx-auto">
								</div>
							 </a>					 
						</div>
					</div>
					<div class="col-12 col-md-6 col-lg-6 gallery-coloum">
						<div class="gallery-wrap service-item">
							 <a href="assets/images/marble/fantasy-white.jpg" data-lightbox="image-1">
								<div class="image-container">
								   <img src="assets/images/marble/fantasy-white.jpg" class="img-fluid d-block mx-auto">
								</div>
							 </a>					 
						</div>
					</div>

				</div>
			</div>			
		</div>
		<div class="row mt-4">
			<div class="col-12">
				<p class="descripton">Honed marble countertops have a matte finish and are more forgiving and a little easier to care for as they will not show any scratches or etching. While polished marble countertops have a sheen they are more vulnerable to scratches and stains that might come from marinade spills and acidic juices. If you have chosen to go with a polished surface, please make sure you remember to dust your marble with a micro fibre cloth to ensure no small particles or granules scratch the surface.<br><br>
				We recommend resealing your marble every year to ensure longevity. Sealers can be bought from your stone supplier or all major hardware stores.<br><br>
The great thing about marble is that any imperfections, stain and chips can be fixed by a reputable stone mason or fabricator.</p>
			</div>
		</div>
		<div class="row mt-4 mt-lg-5">
			<div class="col-12 col-md-6 col-lg-3 gallery-coloum">
				<div class="gallery-wrap service-item">
					 <a href="assets/images/marble/lilac-marble.jpg" data-lightbox="image-1">
						<div class="image-container">
						   <img src="assets/images/marble/lilac-marble.jpg" class="img-fluid d-block mx-auto">
						</div>						
					 </a>
					<div class="gallery-title">Lilac Marble</div>	
				</div>
			</div>
			<div class="col-12 col-md-6 col-lg-3 gallery-coloum">
				<div class="gallery-wrap service-item">
					 <a href="assets/images/marble/matarazzo.jpg" data-lightbox="image-1">
						<div class="image-container">
						   <img src="assets/images/marble/matarazzo.jpg" class="img-fluid d-block mx-auto">
						</div>
					 </a>
					<div class="gallery-title">Matarazzo</div>		
				</div>
			</div>
			<div class="col-12 col-md-6 col-lg-3 gallery-coloum">
				<div class="gallery-wrap service-item">
					 <a href="assets/images/marble/michelangelo-argento.jpg" data-lightbox="image-1">
						<div class="image-container">
						   <img src="assets/images/marble/michelangelo-argento.jpg" class="img-fluid d-block mx-auto">
						</div>
					 </a>
					<div class="gallery-title">Michelangelo Argento</div>		
				</div>
			</div>
			<div class="col-12 col-md-6 col-lg-3 gallery-coloum">
				<div class="gallery-wrap service-item">
					 <a href="assets/images/marble/noir-lauren.jpg" data-lightbox="image-1">
						<div class="image-container">
						   <img src="assets/images/marble/noir-lauren.jpg" class="img-fluid d-block mx-auto">
						</div>
					 </a>	
					<div class="gallery-title">Noir St. Laurent</div>		
				</div>
			</div>
			<div class="col-12 col-md-6 col-lg-3 gallery-coloum">
				<div class="gallery-wrap service-item">
					 <a href="assets/images/marble/panda-white.jpg" data-lightbox="image-1">
						<div class="image-container">
						   <img src="assets/images/marble/panda-white.jpg" class="img-fluid d-block mx-auto">
						</div>
					 </a>	
					<div class="gallery-title">Panda White</div>		
				</div>
			</div>
			<div class="col-12 col-md-6 col-lg-3 gallery-coloum">
				<div class="gallery-wrap service-item">
					 <a href="assets/images/marble/silver-roots.jpg" data-lightbox="image-1">
						<div class="image-container">
						   <img src="assets/images/marble/silver-roots.jpg" class="img-fluid d-block mx-auto">
						</div>
					 </a>
					<div class="gallery-title">Silver Roots</div>		
				</div>
			</div>
			<div class="col-12 col-md-6 col-lg-3 gallery-coloum">
				<div class="gallery-wrap service-item">
					 <a href="assets/images/marble/spider-green.jpg" data-lightbox="image-1">
						<div class="image-container">
						   <img src="assets/images/marble/spider-green.jpg" class="img-fluid d-block mx-auto">
						</div>
					 </a>
					<div class="gallery-title">Spider Green</div>		
				</div>
			</div>	
			<div class="col-12 col-md-6 col-lg-3 gallery-coloum">
				<div class="gallery-wrap service-item">
					 <a href="assets/images/marble/verde-onyx.jpg" data-lightbox="image-1">
						<div class="image-container">
						   <img src="assets/images/marble/verde-onyx.jpg" class="img-fluid d-block mx-auto">
						</div>
					 </a>
					<div class="gallery-title">Verde Onyx</div>		
				</div>
			</div>		
		</div>
	</div>
</section>
<!-- Product Section End --> 


<!-- Footer Include File -->
<?php include 'footer.php'; ?>
<!-- Footer Include File end -->