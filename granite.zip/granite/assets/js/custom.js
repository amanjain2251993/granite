(function($) {

// 1. Header

$(function() {
      		var header = $(".header-fixed");
      		$(window).scroll(function() {    
      			var scroll = $(window).scrollTop();
      		
      			if (scroll >= 10) {
      				header.removeClass('header-fixed').addClass("scroll-on");
      			} else {
      				header.removeClass("scroll-on").addClass('header-fixed');
      			}
      		});
      	});		
      		
      	//Menu On Hover
      		
      	$('body').on('mouseenter mouseleave','.nav-item',function(e){
      			if ($(window).width() > 750) {
      				var _d=$(e.target).closest('.nav-item');_d.addClass('show');
      				setTimeout(function(){
      				_d[_d.is(':hover')?'addClass':'removeClass']('show');
      				},1);
      			}
      	});	
		
// 2. Slider
	
    function bootstrapAnimatedLayer() {

        function doAnimations(elems) {
            //Cache the animationend event in a variable
            var animEndEv = "webkitAnimationEnd animationend";

            elems.each(function() {
                var $this = $(this),
                    $animationType = $this.data("animation");
                $this.addClass($animationType).one(animEndEv, function() {
                    $this.removeClass($animationType);
                });
            });
        }

        //Variables on page load
        var $myCarousel = $("#minimal-bootstrap-carousel"),
            $firstAnimatingElems = $myCarousel
            .find(".carousel-item:first")
            .find("[data-animation ^= 'animated']");

        //Initialize carousel
        $myCarousel.carousel();

        //Animate captions in first slide on page load
        doAnimations($firstAnimatingElems);

        //Other slides to be animated on carousel slide event
        $myCarousel.on("slide.bs.carousel", function(e) {
            var $animatingElems = $(e.relatedTarget).find(
                "[data-animation ^= 'animated']"
            );
            doAnimations($animatingElems);
        });
    }

    bootstrapAnimatedLayer();
	

})(jQuery);


