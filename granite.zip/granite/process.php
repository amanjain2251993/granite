<!-- Header Include File -->
<?php include 'header.php'; ?>
<!-- Header Include File end -->

<!-- Breadcumb Section Start -->
<section class="breadcumb-wrapper">
		<div class="container">
			<div class="row">
				<div class="col-12">
					<h2>Process</h2>
				</div>
			</div>
		</div>
</section>
<!-- Breadcumb Section End -->

<!-- Product Section --> 
<section class="section-padding">
	<div class="container">
		<div class="row">
			<div class="col-12 mb-4 mb-md-5">
				<div class="section-title text-center">
					<h1>Step One</h1>
					<p class="descripton mt-4 text-left">Please contact us to talk about providing you a quote or a showroom consultation either via email, phone or showroom visit.
					Appointment bookings available along with the service of a free measure and quote upon request.
					</p>
				</div>				
			</div>
			<div class="col-12 mb-4 mb-md-5">
				<div class="section-title text-center">
					<h1>Step Two</h1>
					<p class="descripton mt-4 text-left">Once you have chosen your desired stone we then ask for a copy of your signed quote, completed job specification sheet* along with a 50% deposit prior to proceeding onto template.
					</p>
				</div>				
			</div>
			<div class="col-12 mb-4 mb-md-5">
				<div class="section-title text-center">
					<h1>Step Three</h1>
					<p class="descripton mt-4 text-left">Once we have received your relevant paperwork and 50% deposit, we will then send you an email confirmation for your template booking. During this, our template team we come out to your site and complete a digital template to ensure accuracy of measurements.
					</p>
				</div>				
			</div>
			<div class="col-12 mb-4 mb-md-5">
				<div class="section-title text-center">
					<h1>Step Four</h1>
					<p class="descripton mt-4 text-left">It is important that you are happy with the final result of your kitchen benchtop, and to achieve this we will email you a template sign off that specifies the placement and number of joins, colour confirmation and placement of your sink and hob. Once we have received this back from you our template team will then email you the confirmed installation date which is generally between 10-15 working days later.
					</p>
				</div>				
			</div>
			<div class="col-12 mb-4 mb-md-5">
				<div class="section-title text-center">
					<h1>Step Five</h1>
					<p class="descripton mt-4 text-left">A week prior to your scheduled installation you will receive a phone call from our friendly operations manager to confirm the time our team will be on-site to install. Please ensure the area is free from obstructions and allow up to 4 hours for your benchtop to be fully installed.
					</p>
				</div>				
			</div>
			<div class="col-12 mb-4 mb-md-5">
				<div class="section-title text-center">
					<h1>Step Six</h1>
					<p class="descripton mt-4 text-left">Upon completion of your installation, you will be emailed your final invoice for payment 7 days post-install. Once final payment is received your benchtop warranty will be lodged by our team.
					</p>
				</div>				
			</div>			
		</div>		
	</div>
</section>
<!-- Product Section End --> 


<!-- Footer Include File -->
<?php include 'footer.php'; ?>
<!-- Footer Include File end -->