<!-- Header Include File -->
<?php include 'header.php'; ?>
<!-- Header Include File end -->

<!-- Breadcumb Section Start -->
<section class="breadcumb-wrapper">
		<div class="container">
			<div class="row">
				<div class="col-12">
					<h2>Testimonials</h2>
				</div>
			</div>
		</div>
</section>
<!-- Breadcumb Section End -->


<!-- Section --> 
<section class="section-padding">
	<div class="container">
		<div class="row">
			<div class="col-12 col-md-6 col-lg-6 testimonial">
				<div class="content-box">
					<p class="testimonial-headline">This has been the best project we have worked so far!</p>
					<p>interico company has a really proffessional staff. They kept us informed throughout whole process of building our bedroom house. We got suggestions on what materials to choose, the timeframe and price were.</p>
				</div>
				<div class="profile">
					<p class="name">Josh Sinclair</p>
					<p class="company">Manager</p>
				</div>					
			</div>
			<div class="col-12 col-md-6 col-lg-6 testimonial">
				<div class="content-box">
					<p class="testimonial-headline">This has been the best project we have worked so far!</p>
					<p>interico company has a really proffessional staff. They kept us informed throughout whole process of building our bedroom house. We got suggestions on what materials to choose, the timeframe and price were.</p>
				</div>
				<div class="profile">
					<p class="name">Josh Sinclair</p>
					<p class="company">Manager</p>
				</div>					
			</div>
			<div class="col-12 col-md-6 col-lg-6 testimonial">
				<div class="content-box">
					<p class="testimonial-headline">This has been the best project we have worked so far!</p>
					<p>interico company has a really proffessional staff. They kept us informed throughout whole process of building our bedroom house. We got suggestions on what materials to choose, the timeframe and price were.</p>
				</div>
				<div class="profile">
					<p class="name">Josh Sinclair</p>
					<p class="company">Manager</p>
				</div>					
			</div>
			<div class="col-12 col-md-6 col-lg-6 testimonial">
				<div class="content-box">
					<p class="testimonial-headline">This has been the best project we have worked so far!</p>
					<p>interico company has a really proffessional staff. They kept us informed throughout whole process of building our bedroom house. We got suggestions on what materials to choose, the timeframe and price were.</p>
				</div>
				<div class="profile">
					<p class="name">Josh Sinclair</p>
					<p class="company">Manager</p>
				</div>					
			</div>			
		</div>		
		
	</div>
</section>
<!-- Section End --> 



<!-- Footer Include File -->
<?php include 'footer.php'; ?>
<!-- Footer Include File end -->