<!-- Header Include File -->
<?php include 'header.php'; ?>
<!-- Header Include File end -->

<!-- Breadcumb Section Start -->
<section class="breadcumb-wrapper">
		<div class="container">
			<div class="row">
				<div class="col-12">
					<h2>Projects</h2>
				</div>
			</div>
		</div>
</section>
<!-- Breadcumb Section End -->


<!-- Section --> 
<section class="section-padding">
	<div class="container">
		<div class="row">
			<div class="col-12 mb-4 mb-md-5">
				<div class="section-title text-center">
					<h3>GREAT THINGS WE'VE DONE</h3>
					<h1>Projects</h1>
				</div>
			</div>
			<div class="col-12 col-md-6 col-lg-4 gallery-coloum">
				<div class="gallery-wrap service-item">
					 <a href="assets/images/projects/1.jpg" data-lightbox="image-1">
						<div class="image-container">
						   <img src="assets/images/projects/1.jpg" class="img-fluid d-block mx-auto">
						</div>						
					 </a>
					<div class="gallery-title">Product 1</div>	
				</div>
			</div>
			<div class="col-12 col-md-6 col-lg-4 gallery-coloum">
				<div class="gallery-wrap service-item">
					 <a href="assets/images/projects/2.jpg" data-lightbox="image-1">
						<div class="image-container">
						   <img src="assets/images/projects/2.jpg" class="img-fluid d-block mx-auto">
						</div>
					 </a>
					<div class="gallery-title">Product 2</div>		
				</div>
			</div>
			<div class="col-12 col-md-6 col-lg-4 gallery-coloum">
				<div class="gallery-wrap service-item">
					 <a href="assets/images/projects/3.jpg" data-lightbox="image-1">
						<div class="image-container">
						   <img src="assets/images/projects/3.jpg" class="img-fluid d-block mx-auto">
						</div>
					 </a>
					<div class="gallery-title">Product 3</div>		
				</div>
			</div>
			<div class="col-12 col-md-6 col-lg-4 gallery-coloum">
				<div class="gallery-wrap service-item">
					 <a href="assets/images/projects/4.jpg" data-lightbox="image-1">
						<div class="image-container">
						   <img src="assets/images/projects/4.jpg" class="img-fluid d-block mx-auto">
						</div>
					 </a>	
					<div class="gallery-title">Product 4</div>		
				</div>
			</div>
			<div class="col-12 col-md-6 col-lg-4 gallery-coloum">
				<div class="gallery-wrap service-item">
					 <a href="assets/images/projects/5.jpg" data-lightbox="image-1">
						<div class="image-container">
						   <img src="assets/images/projects/5.jpg" class="img-fluid d-block mx-auto">
						</div>
					 </a>	
					<div class="gallery-title">Product 5</div>		
				</div>
			</div>
			<div class="col-12 col-md-6 col-lg-4 gallery-coloum">
				<div class="gallery-wrap service-item">
					 <a href="assets/images/projects/6.jpg" data-lightbox="image-1">
						<div class="image-container">
						   <img src="assets/images/projects/6.jpg" class="img-fluid d-block mx-auto">
						</div>
					 </a>
					<div class="gallery-title">Product 6</div>		
				</div>
			</div>			
		</div>	
	</div>
</section>
<!-- Section End --> 


<!-- Footer Include File -->
<?php include 'footer.php'; ?>
<!-- Footer Include File end -->