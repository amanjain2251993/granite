<!-- Header Include File -->
<?php include 'header.php'; ?>
<!-- Header Include File end -->

<!-- Banner slides Section -->
 <div id="minimal-bootstrap-carousel" class="carousel slide carousel-fade slider-content-style slider-home-one">            
	<div class="carousel-inner">
	   <div class="carousel-item active slide-1" style="background-image:url(assets/images/slider/slider-1.png);">
		  <div class="carousel-caption">
			 <div class="container">
				<div class="box valign-middle">
				   <div class="content">
					  <h3 data-animation="animated fadeInUp">Lets make your vision reality</h3>
					  <p data-animation="animated fadeInUp">We strive to provide each client
						 with custom made services
						 specifically designed for their needs
						 and requirements
					  </p>
					  <a data-animation="animated fadeInDown" href="javascript:void(0);" data-toggle="modal" data-target="#contactModal" class="thm-btn m-red-btn hvr-shrink">Get a free quote</a>
				   </div>
				</div>
			 </div>
		  </div>
	   </div>	   
	   <div class="carousel-item slide-4" style="background-image:url(assets/images/slider/slider-4.png);">
		  <div class="carousel-caption">
			 <div class="container">
				<div class="box valign-middle">
				   <div class="content">
					  <h3 data-animation="animated fadeInUp">Lets make your vision reality</h3>
					  <p data-animation="animated fadeInUp">We strive to provide each client
						 with custom made services
						 specifically designed for their needs
						 and requirements
					  </p>
					  <a data-animation="animated fadeInDown" href="javascript:void(0);" data-toggle="modal" data-target="#contactModal" class="thm-btn m-red-btn hvr-shrink">Get a free quote</a>
				   </div>
				</div>
			 </div>
		  </div>
	   </div>	   
	</div>
	<!-- Controls -->
	<a class="carousel-control-prev" href="#minimal-bootstrap-carousel" role="button" data-slide="prev">
	<i class="fa fa-angle-left" aria-hidden="true"></i>
	<span class="sr-only">Previous</span>
	</a>
	<a class="carousel-control-next" href="#minimal-bootstrap-carousel" role="button" data-slide="next">
	<i class="fa fa-angle-right" aria-hidden="true"></i>
	<span class="sr-only">Next</span>
	</a>
 </div>
<!-- Banner slides Section End --> 

<!-- What We do Section --> 
<section class="services-bg section-padding">
	<div class="container">
		<div class="row">
			<div class="col-12 mb-md-4">
				<div class="section-title text-center">
					<h3>WHAT WE DO</h3>
					<h1>Passion Fueled <br class="d-none d-md-block">
					<span>Benchtop</span> Services</h1>
					<p class="my-4">Granite Tops Ltd are a premium Granite Company specialising in high quality granite Kitchen<br class="d-none d-md-block"> Bench tops, Vanity tops, Tiles, Fireplaces etc.</p>
					<a href="granite.html" class="normal-btn m-red-btn hvr-shrink">Know More</a>
				</div>
			</div>
			<div class="col-12 col-md-6 col-lg-3">
					  <div class="service-wrap service-item">
						 <a href="engineered-stone.html">
							<div class="image-container">
							   <div class="vertical-number-box"> <span class="vertical-number">01</span></div>
							   <img src="assets/images/services/service-4.jpg" class="img-fluid d-block mx-auto" alt="Engineered Stone">
							</div>
							<div class="content-box-info">
							   <h4 class="box-heading">Engineered Stone</h4>
							</div>
						 </a>						 
					  </div>
			</div>
			<div class="col-12 col-md-6 col-lg-3">
					  <div class="service-wrap service-item">
						 <a href="granite.html">
							<div class="image-container">
							   <div class="vertical-number-box"> <span class="vertical-number">02</span></div>
							   <img src="assets/images/services/service-1.jpg" class="img-fluid d-block mx-auto" alt="Granite">
							</div>
							<div class="content-box-info">
							   <h4 class="box-heading">Granite</h4>
							</div>
						 </a>						 
					  </div>
			</div>
			<div class="col-12 col-md-6 col-lg-3">
					  <div class="service-wrap service-item">
						 <a href="porcelain.html">
							<div class="image-container">
							   <div class="vertical-number-box"> <span class="vertical-number">03</span></div>
							   <img src="assets/images/services/service-2.jpg" class="img-fluid d-block mx-auto" alt="Porcelain">
							</div>
							<div class="content-box-info">
							   <h4 class="box-heading">Porcelain</h4>
							</div>
						 </a>						 
					  </div>
			</div>
			<div class="col-12 col-md-6 col-lg-3">
					<div class="service-wrap service-item">
						 <a href="marble.html">
							<div class="image-container">
							   <div class="vertical-number-box"> <span class="vertical-number">04</span></div>
							   <img src="assets/images/services/service-3.jpg" class="img-fluid d-block mx-auto" alt="Marble">
							</div>
							<div class="content-box-info">
							   <h4 class="box-heading">Marble</h4>
							</div>
						 </a>						 
				    </div>
			</div>			
		</div>
	</div>
</section>
<!-- What We do Section End --> 

<!-- About Section --> 
<section class="section-padding">
	<div class="container">
		<div class="row">
			<div class="col-12 col-md-7 col-lg-6 order-md-2 pl-lg-5 d-flex align-items-center">
				<div class="section-title">
					<h3>OUR PROCESS</h3>
					<h1>From Template to <span>Life</span></h1>
					<p class="my-4">The basic philosophy of our companyis to create individual, aesthetically stunning solutions for our customers by lightning-fast development of projects employing unique styles. Even if you don’t have anything in place of what you want – we will help you to get the result you dreamed of.</p>
					<a href="why-choose-us.html" class="normal-btn m-red-btn mt-md-5 hvr-shrink">Know More</a>
				</div>
			</div>
			<div class="col-12 col-md-5 col-lg-6 order-md-1 mt-4 mt-md-0 d-flex align-items-center">
			  <img src="assets/images/aboutus.png" class="img-fluid d-block mx-auto" alt="Marble">
			</div>			
		</div>
	</div>
</section>
<!-- About Section End --> 

<!-- Our Spaces Section End --> 
<section>
	<div class="container-fluid p-0">
		<div class="row no-gutters">
			<div class="col-12 col-md-4">
				<div class="cate-lines">
					<img src="assets/images/resenditial-spaces.png" class="img-fluid d-block mx-auto" alt="resenditial-spaces">
					<div class="cate-item_content">
						<h2>Residential Spaces</h2>
					</div>
				</div>
			</div>
			<div class="col-12 col-md-4">
				<div class="cate-lines">
					<img src="assets/images/commercial-spaces.png" class="img-fluid d-block mx-auto" alt="Commercial Spaces">
					<div class="cate-item_content">
						<h2>Commercial Spaces</h2>
					</div>
				</div>
			</div>
			<div class="col-12 col-md-4">
				<div class="cate-lines">
					<img src="assets/images/public-spaces.png" class="img-fluid d-block mx-auto" alt="Public Spaces">
					<div class="cate-item_content">
						<h2>Public Spaces</h2>
					</div>
				</div>
			</div>			
		</div>
	</div>
</section>
<!-- Our Spaces Section End --> 

<!-- Our Services Section --> 
<section class="our-services section-padding">
	<div class="container">
		<div class="row">
			<div class="col-12 mb-md-4">
				<div class="section-title text-center">
					<h3>OUR SERVICES</h3>
					<h1>What We Can <span>Offer</span></h1>
				</div>
			</div>
			<div class="col-12 col-md-4">
				<div class="our-services-box">
					<img src="assets/images/services/shape.png" class="img-fluid d-block mx-auto">
					<div class="title">Design & Planning</div>
					<div class="descripton">We will help you to get the result you dreamed of. <br><br></div>
				</div>
			</div>
			<div class="col-12 col-md-4">
				<div class="our-services-box">
					<img src="assets/images/services/shape1.png" class="img-fluid d-block mx-auto">
					<div class="title">Custom Solutions</div>
					<div class="descripton">Individual, aesthetically stunning solutions for customers.</div>
				</div>
			</div>
			<div class="col-12 col-md-4">
				<div class="our-services-box">
					<img src="assets/images/services/shape2.png" class="img-fluid d-block mx-auto">
					<div class="title">Wide Range</div>
					<div class="descripton"> We have over 30 colours of Granite to choose from <br><br></div>
				</div>
			</div>			
		</div>
	</div>
</section>
<!-- Our Services Section End --> 

<!-- Our Gallery Section End --> 
<div class="container-fluid p-0">
	<div class="row no-gutters">
		<div class="col-12 col-md-6">
			<div class="projects-box">
				<div class="projects-thumbnail">
					<img src="assets/images/gallery/1.jpg" class="img-fluid d-block mx-auto">
				</div>
				<!--<div class="portfolio-info">
					<div class="portfolio-info-inner">
					<h5>Granite</h5>                                      
					</div>
				</div>-->
			</div>
		</div>
		<div class="col-12 col-md-3">
			<div class="projects-box">
				<div class="projects-thumbnail">
					<img src="assets/images/gallery/2.jpg" class="img-fluid d-block mx-auto">
				</div>
				<!--<div class="portfolio-info">
					<div class="portfolio-info-inner">
					<h5>Granite</h5>                                      
					</div>
				</div>-->
			</div>
		</div>
		<div class="col-12 col-md-3">
			<div class="projects-box">
				<div class="projects-thumbnail">
					<img src="assets/images/gallery/3.jpg" class="img-fluid d-block mx-auto">
				</div>
				<!--<div class="portfolio-info">
					<div class="portfolio-info-inner">
					<h5>Granite</h5>                                      
					</div>
				</div>-->
			</div>
		</div>
		<div class="col-12 col-md-3">
			<div class="projects-box">
				<div class="projects-thumbnail">
					<img src="assets/images/gallery/4.jpg" class="img-fluid d-block mx-auto">
				</div>
				<!--<div class="portfolio-info">
					<div class="portfolio-info-inner">
					<h5>Granite</h5>                                      
					</div>
				</div>-->
			</div>
		</div>
		<div class="col-12 col-md-3">
			<div class="projects-box">
				<div class="projects-thumbnail">
					<img src="assets/images/gallery/5.jpg" class="img-fluid d-block mx-auto">
				</div>
				<!--<div class="portfolio-info">
					<div class="portfolio-info-inner">
					<h5>Granite</h5>                                      
					</div>
				</div>-->
			</div>
		</div>
		<div class="col-12 col-md-6">
			<div class="projects-box">
				<div class="projects-thumbnail">
					<img src="assets/images/gallery/6.jpg" class="img-fluid d-block mx-auto">
				</div>
				<!--<div class="portfolio-info">
					<div class="portfolio-info-inner">
					<h5>Granite</h5>                                      
					</div>
				</div>-->
			</div>
		</div>
	</div>
</div>
<!-- Our Gallery Section End --> 

<!-- TESTIMONIALS Section --> 
<section class="section-padding">
	<div class="container">
		<div class="row">
			<div class="col-12">
				<div class="section-title text-center">
					<h3>TESTIMONIALS</h3>
					<h1>What Our  <span>Customers </span> Say</h1>
				</div>
			</div>			
		
			<div class="testimonails-card col-12 mx-auto mt-2 mt-md-5">
				<div id="carouselExampleControls" class="carousel slide" data-ride="carousel" data-interval="100000">
					<div class="w-75 mx-auto carousel-inner" role="listbox">
					  <div class="carousel-item active">
						<div class="carousel-caption">
						   <h3>Gives me hope</h3>
							  <p>Well incremented. Comes with recommended workout. I'm using it to help with bladder leakage issues that I've been experiencing since a recent vasectomy.</p>
						</div>
					  </div>
					  <div class="carousel-item">
						<div class="carousel-caption">
						   <h3>Gives me hope</h3>
							  <p>Well incremented. Comes with recommended workout. I'm using it to help with bladder leakage issues that I've been experiencing since a recent vasectomy.</p>
						</div>
					  </div>
					  <div class="carousel-item">
						<div class="carousel-caption">
						   <h3>Gives me hope</h3>
							  <p>Well incremented. Comes with recommended workout. I'm using it to help with bladder leakage issues that I've been experiencing since a recent vasectomy.</p>
						</div>
					  </div>
					</div>
				<a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
					<i class="fa fa-angle-left" aria-hidden="true"></i>
					<span class="sr-only">Previous</span>
				</a>
				<a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
					<i class="fa fa-angle-right" aria-hidden="true"></i>
					<span class="sr-only">Next</span>
				</a>
				</div>
			</div>	
		</div>
	</div>
</section>
<!-- TESTIMONIALS Section End --> 


<!-- Footer Include File -->
<?php include 'footer.php'; ?>
<!-- Footer Include File end -->