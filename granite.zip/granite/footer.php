<footer class="footer-section">
      <div class="container">
         <div class="row">
            <div class="col-12 col-md-12 col-lg-3">
                  <img src="assets/images/logo.png" alt="Granite Tops Ltd" class="img-fluid d-block">
                  <div class="textwidget">
                     <p>Granite Tops Ltd are a premium Granite Company specialising in high quality granite Kitchen Bench tops, Vanity tops, Tiles, Fireplaces etc.</p>
                  </div>
            </div>
            <div class="col-12 col-md-6 col-lg-3 mt-4 mt-lg-0">
                  <h4 class="footer-header">Our Link</h4>
                  <div class="menu-about-us-container">
                     <ul>
                        <li><a href="why-choose-us.php">About us</a></li>                        
                        <li><a href="granite.php">Products</a></li>                        
                        <li><a href="process.php">Process</a></li>                        
                     </ul>
                  </div>
            </div>
            <div class="col-12 col-md-6 col-lg-3 mt-4 mt-lg-0">
                  <h4 class="footer-header">Our Link</h4>
                  <div class="menu-services-container">
                     <ul>
                        <li><a href="projects.php">Projects</a></li>                        
                        <li><a href="faqs.php">FAQS</a></li>                        
                        <li><a href="contact-us.php">Contact Us</a></li>                        
                     </ul>
               </div>
            </div>
            <div class="col-12 col-md-5 col-lg-3 mt-4 mt-lg-0">
                  <h4 class="footer-header">Contact us</h4>
                  <div class="textwidget">
                     Phone :  06-368 6408
                     <hr>
                     Email : info@granitetopsltd.co.nz
                     <hr>
                     Address : 27 Main Road South, Levin
                                   
                  </div>
            </div>
			<div class="col-12">
                  <div class="textwidget text-center sep-border">
                    2021. All Rights Reserved to Granite Tops Ltd      
                  </div>
            </div>
         </div>
      </div>
</footer>

</div>
<!-- Content Section End -->


<!-- The Modal -->
<div class="modal" id="contactModal">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <!-- Modal body -->
      <div class="modal-body form-style">
	  <a href="#" class="close-icon" data-dismiss="modal"><i class="fa fa-close"></i></a>
	  <div class="section-title">
					<h3>Get Free Quote</h3>
					<h1>Let's work <span>together</span></h1>
				</div>
				<div id="error_message" class="ajax_response" style="float:left"></div>
				<div id="success_message" class="ajax_response" style="float:left"></div>
        <div id="frmContact">
          <div class="form-group mt-4">
            <input type="text" class="form-control" name="userName" id="userName" placeholder="Full Name" >
			<span id="userName-info" class="info"></span>
			</div>
          <div class="form-group">
            <input type="email" class="form-control"  name="userEmail" id="userEmail" placeholder="E-mail" >
			<span id="userEmail-info" class="info"></span>
			</div>
          <div class="form-group">
            <input type="tel" class="form-control" name="subject" id="subject" placeholder="Phone" >
			<span id="subject-info" class="info"></span>
			</div>
          <div class="form-group">
            <textarea class="form-control"  name="content" id="content" rows="4" placeholder="Your Message"></textarea>
			<span id="userMessage-info" class="info"></span>
          </div>
          <button type="submit" class="normal-btn m-red-btn px-5" onClick="sendContact();">Get in Touch</button>
        
      </div>
	  </div>


    </div>
  </div>
</div>


<!-- Jquery Files -->
<script type='text/javascript' src="<?php echo $basedir; ?>assets/js/jquery.min.js"></script>
<script type='text/javascript' src="<?php echo $basedir; ?>assets/js/popper.min.js"></script> 
<script type='text/javascript' src="<?php echo $basedir; ?>assets/js/bootstrap.min.js"></script> 
<script type='text/javascript' src="<?php echo $basedir; ?>assets/js/custom.js"></script> 
<script type='text/javascript' src="<?php echo $basedir; ?>assets/js/lightbox.js"></script>
<script src="https://code.jquery.com/jquery-2.2.4.min.js" type="text/javascript"></script>
<script>
function sendContact() {
	var valid;	
	valid = validateContact();
	if(valid) {
		jQuery.ajax({
		url: "contact_mail.php",
		data:'userName='+$("#userName").val()+'&userEmail='+$("#userEmail").val()+'&subject='+$("#subject").val()+'&content='+$("#content").val(),
		type: "POST",
		success:function(data){
		$('#success_message').fadeIn().html('Contact Mail Sent');
		setTimeout(function() {
			$('#success_message').fadeOut("slow");
		}, 2000 );
		$(".form-control").val('');
		//$('#contactModal').hide();
		},
		error:function (){}
		});
	}
}

function validateContact() {
	var valid = true;	
	$(".form-control").css('border', '');
	$(".info").html('');
	
	if(!$("#userName").val()) {
		$("#userName-info").html("Required");
		$("#userName").css('border', '#e66262 1px solid');
		valid = false;
	}
	if(!$("#userEmail").val()) {
		$("#userEmail-info").html("Required");
		$("#userEmail").css('border', '#e66262 1px solid');
		valid = false;
	}
	if(!$("#userEmail").val().match(/^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/)) {
		$("#userEmail-info").html("Enter Valid Email-id");
		$("#userEmail").css('border', '#e66262 1px solid');
		valid = false;
	}	
	if(!$("#subject").val()) {
		$("#subject-info").html("Required");
		$("#subject").css('border', '#e66262 1px solid');
		valid = false;
	}
	if(!$("#subject").val().match(/^\d{10}$/)) {
		$("#subject-info").html("Enter Valid Phone Number");
		$("#subject").css('border', '#e66262 1px solid');
		valid = false;
	}
	if(!$("#content").val()) {
		$("#content-info").html("Required");
		$("#content").css('border', '#e66262 1px solid');
		valid = false;
	}
	
	return valid;
}
function flashshow(data){
	$("body").append('<div class="alert alert-success alert-dismissable" style="position:fixed;  top:100px;  right:30px;  z-index:9999;" >'+
    '<a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>'+
    '<strong>Success!</strong>'+data+'</div>');
}



</script>
 
</body>
</html>