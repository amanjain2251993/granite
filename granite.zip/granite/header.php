<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
   <head>
	<title>Granite Tops Ltd - Supplier of Granite & Engineered Stones</title>
	<meta name="title" content="Granite Tops Ltd - Supplier of Granite & Engineered Stones">
	<meta name="description" content="Granite Tops Ltd - Supplier of Granite & Engineered Stones">
	<meta name="keywords" content="Granite Tops Ltd">
	<meta name="robots" content="noindex, nofollow">
	<meta name="language" content="English">
	<meta name="revisit-after" content="1 days">
	<meta name="author" content="">
	<meta property="og:type" content="website">
	<meta property="og:url" content="">
	<meta property="og:title" content="Granite Tops Ltd - Supplier of Granite & Engineered Stones">
	<meta property="og:description" content="Granite Tops Ltd - Supplier of Granite & Engineered Stones">
	<meta property="og:image" content="#">
	<meta property="twitter:card" content="Lg_image">
	<meta property="twitter:url" content="#">
	<meta property="twitter:title" content="Granite Tops Ltd - Supplier of Granite & Engineered Stones">
	<meta property="twitter:description" content="Granite Tops Ltd - Supplier of Granite & Engineered Stones">
	<meta property="twitter:image" content="#">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
	<meta name="google" content="notranslate"/>
	<!-- Tell the browser to be responsive to screen width -->
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
	<?php $basedir = "http://".$_SERVER['SERVER_NAME'] . '/granite/'; ?>
	<link rel="icon" href="<?php echo $basedir; ?>assets/images/favicon.png" type="image/png">
	<link rel="stylesheet" href="<?php echo $basedir; ?>assets/css/bootstrap.min.css">
	<link rel='stylesheet' href='<?php echo $basedir; ?>assets/css/animate.min.css'>
	<link rel='stylesheet' href='<?php echo $basedir; ?>assets/css/hover.css'>
	<link rel='stylesheet' href='<?php echo $basedir; ?>assets/css/font-awesome.min.css'>
	<link rel="stylesheet" href="<?php echo $basedir; ?>assets/css/style.css">
	</head>
<body>
<!-- Header -->
<div class="navigation-wrap header-style header-fixed">
 <div class="container">
	<div class="row">
	   <div class="col-12">
		  <nav class="navbar navbar-expand-lg navbar-light">
			 <a class="navbar-brand" href="index.php"><img src="assets/images/logo.png" alt="Granite Tops Ltd"></a>	
			 <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
			 <span class="navbar-toggler-icon"></span>
			 </button>
			 <div class="collapse navbar-collapse" id="navbarSupportedContent">
				<div class="d-flex flex-wrap justify-content-lg-end">
				   <div class="w-100 top-header text-right d-flex justify-content-end align-items-center">
					  <div class="mr-3">27 Main Road South, Levin | info@granitetopsltd.co.nz | 06-368 6408</div>
					  <a href="javascript:void(0);" class="normal-btn m-red-btn" data-toggle="modal" data-target="#contactModal">Get a free quote</a>
				   </div>
				   <ul class="navbar-nav mt-2">
					  <li class="nav-item">
						 <a class="nav-link" href="index.php">Home</a>
					  </li>
					  <li class="nav-item">
                              <a class="nav-link dropdown-toggle" data-toggle="dropdown" href="javascript:void(0);" role="button" aria-haspopup="true" aria-expanded="false">About Us</a>
                              <div class="dropdown-menu">
                                 <a class="dropdown-item" href="why-choose-us.php">Why Choose Us</a>
                                 <a class="dropdown-item" href="testimonials.php">Testimonials</a>
                              </div>
                      </li>
					  <li class="nav-item">
						  <a class="nav-link dropdown-toggle" data-toggle="dropdown" href="javascript:void(0);" role="button" aria-haspopup="true" aria-expanded="false">Products</a>
                              <div class="dropdown-menu">
								  <a class="dropdown-item" href="engineered-stone.php">Engineered Stone</a>	
                                 <a class="dropdown-item" href="granite.php">Granite</a>
                                 <a class="dropdown-item" href="porcelain.php">Porcelain</a>
                                 <a class="dropdown-item" href="marble.php">Marble</a>
                              </div>
					  </li>
					  <li class="nav-item">
						 <a class="nav-link" href="process.php">Process</a>
					  </li>
					  <li class="nav-item">
						 <a class="nav-link" href="projects.php">Projects</a>
					  </li>
					  <li class="nav-item">
						 <a class="nav-link" href="faqs.php">Faqs</a>
					  </li>
					  <li class="nav-item">
						 <a class="nav-link" href="contact-us.php">Contact Us</a>
					  </li>
				   </ul>
				</div>
			 </div>
		  </nav>
	   </div>
	</div>
 </div>
</div>
<!-- Header End -->
  
<!-- Content Section -->  
<div class="content-section">

<!-- Top Header Section -->
 <div class="top-header-xsdevice d-flex justify-content-center align-items-center flex-wrap flex-md-nowrap">
	<div class="mr-3 text-center text-md-left">27 Main Road South, Levin | info@granitetopsltd.co.nz | 06-368 6408</div>
	<a href="javascript:void(0);" data-toggle="modal" data-target="#contactModal" class="normal-btn m-red-btn mt-2 mt-md-0">Get a free quote</a>
 </div>
<!-- Top Header Section End -->