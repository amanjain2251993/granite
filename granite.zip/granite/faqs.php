<!-- Header Include File -->
<?php include 'header.php'; ?>
<!-- Header Include File end -->

<!-- Breadcumb Section Start -->
<section class="breadcumb-wrapper">
		<div class="container">
			<div class="row">
				<div class="col-12">
					<h2>Faqs</h2>
				</div>
			</div>
		</div>
</section>
<!-- Breadcumb Section End -->


<!-- About Section --> 
<section class="section-padding">
	<div class="container">
		<div class="row">
			
			 <div class="col-12">
                  <div class="faq-accordion">
                      <div class="faq-heading">
                       About Granite 
                      </div>
                      <div id="accordion-1">
                        <div class="card">
                          <div class="card-header" id="headingOne">
                              <a data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                               Is Granite a do-it-yourself product?
                              </a>
                          </div>
                          <div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordion-1">
                            <div class="card-body">
                              <p>No, not likely! Granite fabrication is a specialised trade that requires extensive training and practice in order to produce high-quality results - not to mention the expensive diamond tooling and equipment. Granite Tops employs fabricators and installers with years of training and experience. Even a small vanity countertop can weigh over couple of hundred kilos, so safe handling is another concern that you need not worry about when buying from Granite Tops. Mistakes are inevitable with DIY projects, and when working with natural stone, small errors can be VERY costly - you can easily exceed the cost of our installed prices with just one small slip-up or miscalculation. When you choose Granite Tops, you are guaranteed professional results up to final installation.</p>
                            </div>
                          </div>
                        </div>
                        <div class="card">
                          <div class="card-header" id="headingTwo">
                              <a data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                What's the difference between marble and granite?
                              </a>
                          </div>
                          <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordion-1">
                            <div class="card-body">
                              <p>Although both are stones and both are quarried from the earth, granite and marble (and marble's relatives – Limestone, Onyx and Travertine) are very different from each other. Granite is formed deep in the earth’s mantle at extremely high temperatures, and is a very hard, resistant stone made of crystallised minerals.<br><br>
The marble family – Limestone, Travertine, Marble, Onyx – starts out as sediment – animal skeletons and shells, plant matter, silt – at the bottom of bodies of water. After millions of years this solidifies (lithifies) into stone. Because its main component is calcium, it can be affected by acids such as vinegar and citrus beverages.
                            </p></div>
                          </div>
                        </div>
                        <div class="card">
                          <div class="card-header" id="headingThree">
                              <a data-toggle="collapse" data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                               What is Granite?
                              </a>
                          </div>
                          <div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-parent="#accordion-1">
                            <div class="card-body">
                              <p>Granite is a common and widely-occurring group of intrusive felsic igneous rocks that form at great depths and pressures under continents. It is coarse grained crystalline igneous rock composed primarily of quartz and feldspar. Granite is an elegant natural stone which has extraordinary range of colours and patterns. It is bacteria, scratch and heat resistant rock which needs minimal maintenance and easy to clean.<br><br>
Each piece of granite displays color variations inherent in natural stone. It is difficult to reproduce the actual color and depth of granite on the printed page. We suggest that final selections be made from actual samples whenever possible.<br><br>
Granite is formed by the hands of God. Obviously, no factory can replicate the Creators hands. For that very reason, no synthetic countertop can capture the beauty and character of real granite in all its complexity."
                            </p></div>
                          </div>
                        </div>
						<div class="card">
                          <div class="card-header" id="headingFour">
                              <a data-toggle="collapse" data-target="#collapseFour" aria-expanded="false" aria-controls="collapseThree">
                              What are the main characteristics of granite?
                              </a>
                          </div>
                          <div id="collapseFour" class="collapse" aria-labelledby="headingFour" data-parent="#accordion-1">
                            <div class="card-body">
                              <p>
								<ul class="listing">
								<li>Naturally Beautiful with Unique Pattern and Colour</li>
								<li>Heat-Resistant</li>
								<li>Scratch-Resistant</li>
								<li>Stain, mould and mildew-resistant with proper care and maintenance.</li>
								</ul>
								</p>
							</div>
                          </div>
                        </div>
						
						<div class="card">
                          <div class="card-header" id="headingFive">
                              <a data-toggle="collapse" data-target="#collapseFive" aria-expanded="false" aria-controls="collapseFive">
                             What are the DO's and DON'Ts of Granite?
                              </a>
                          </div>
                          <div id="collapseFive" class="collapse" aria-labelledby="headingFive" data-parent="#accordion-1">
                            <div class="card-body">
                              <p>
								<ul class="listing">
								<li>DO use Granite & Marble Sealer to protect your stone.</li>
<li>DO clean up spills immediately to minimise damage to your stone.</li>
<li>DO use trivets or mats under hot dishes and cookware.</li>
<li>DO use place mats under china, ceramics, silver and other objects that can scratch your stone's surface.</li>
<li>DO use coasters under glasses, especially if they contain alcohol or citrus juices.</li>
<li>DO clean surfaces regularly with Granite & Marble Kitchen Countertop Cleaner.</li>
<li>DO call our office for assistance.</li>
<li>DON'T wait to clean up spills on stone.</li>
<li>DON'T use cleaners that contain acid such as bathroom cleaners, grout cleaners or tub cleaners.</li>
<li>DON'T use vinegar, bleach, ammonia or other general-purpose cleaners.</li>
<li>DON'T use abrasive cleaners such as dry cleansers or soft cleansers.</li>
<li>DON'T use alkaline cleaners, not specifically formulated for stone.</li>
								</ul>
								</p>
							</div>
                          </div>
                        </div>
                      </div>
                  </div>
                </div>
				
				
				<div class="col-12 mt-md-4">
                  <div class="faq-accordion">
                      <div class="faq-heading">
                       Bench Tops 
                      </div>
                      <div id="accordion-2">
                        <div class="card">
                          <div class="card-header" id="headingOne">
                              <a data-toggle="collapse" data-target="#collapseOne1" aria-expanded="true" aria-controls="collapseOne">
                               Why use Granite for Kitchen Bench Tops?
                              </a>
                          </div>
                          <div id="collapseOne1" class="collapse show" aria-labelledby="headingOne" data-parent="#accordion-2">
                            <div class="card-body">
                              <p>Granite is the most popular choice for kitchen counter tops. A solid quality countertop can define a kitchen. The inclusion of a granite counter top will add class to the most modest of kitchens. Granite countertops strikes a perfect balance between function and style. Besides lending your kitchen an elegant, polished look, they are highly resistant to wear, are inhospitable to bacteria and mildew, and can take a lot of impact. Granite is exposed to extremely high pressures and temperatures during formation, making it highly resistant to heat. You can place a pot fresh out of the fire onto a granite countertop without melting or deforming the surface. Also, because of its rocky composition, granite is very compact and durable. A granite countertop will last as long as your home does, maybe longer.</p>
                            </div>
                          </div>
                        </div>
                        <div class="card">
                          <div class="card-header" id="headingTwo">
                              <a data-toggle="collapse" data-target="#collapseTwo2" aria-expanded="false" aria-controls="collapseTwo">
                               How do I know Granite Tops's granite is high quality?
                              </a>
                          </div>
                          <div id="collapseTwo2" class="collapse" aria-labelledby="headingTwo" data-parent="#accordion-2">
                            <div class="card-body">
                              <p>Granite Tops supplies only first quality material. The quality of the material is determined by measuring different parameters of a granite product through the entire production process:
                            </p>
							<ul class="listing">
								<li>Mining - Granite Tops's granites are mined utilising modern methods ensuring slabs are of high quality.</li>
<li>Cutting - Granite Tops's granites are cut by using water as coolant to ensure a lifetime guarantee on the quality of the product.</li>
<li>Dimensions - Product dimensions are controlled within the stipulated limits in ASTM standards. Tiles are calibrated to ensure their thickness is uniform. Gauging is done to ensure the tiles are square. Bevelling is done to produce a smooth edge on the tiles.</li>
<li>Inspection - Inspection is done at different stages of the manufacturing process and the products are segregated for unusual patches, major colour variation, cracks, dimensions, surface finish, and other quality issues. They are then categorised as first, second, and commercial quality. Granite Tops supplies only first quality material.</li>
								</ul>
							</div>
                          </div>
                        </div>
                        <div class="card">
                          <div class="card-header" id="headingThree">
                              <a data-toggle="collapse" data-target="#collapseThree3" aria-expanded="false" aria-controls="collapseThree">
                               Can granite get stained and do I need to seal it?
                              </a>
                          </div>
                          <div id="collapseThree3" class="collapse" aria-labelledby="headingThree" data-parent="#accordion-2">
                            <div class="card-body">
                              <p>Because of its non porous nature granite is compact material, granite allows no room for water to seep in. This dryness creates less vulnerable environment for bacteria to grow. Being dense material some colours of granite are porous and susceptible to stains due to spills etc. It is always good to clean the top as soon as spill occurs. Sealing the surfaces with a water based sealant can protect the surface from water patches and stains.  </p></div>
                          </div>
                        </div>
						<div class="card">
                          <div class="card-header" id="headingFour">
                              <a data-toggle="collapse" data-target="#collapseFour4" aria-expanded="false" aria-controls="collapseThree">
                              Can granite crack?
                              </a>
                          </div>
                          <div id="collapseFour4" class="collapse" aria-labelledby="headingFour" data-parent="#accordion-2">
                            <div class="card-body">
                              <p>
								Granite does not crack with ordinary use. Granite is most susceptible to cracks during fabrication, shipping and installation. Granite will not flex like laminate and solid surface tops. Do not stand on or next to the sink, cooktop cutouts, or unsupported overhangs - as too much stress or weight applied to the stone may cause it to crack as it brittle in unsupported areas.
								</p>
							</div>
                          </div>
                        </div>
						
						<div class="card">
                          <div class="card-header" id="headingFive">
                              <a data-toggle="collapse" data-target="#collapseFive5" aria-expanded="false" aria-controls="collapseFive">
                            Can granite scratch?
                              </a>
                          </div>
                          <div id="collapseFive5" class="collapse" aria-labelledby="headingFive" data-parent="#accordion-2">
                            <div class="card-body">
                              <p>
								Granite is one of the hardest stones available. It is extremely difficult to scratch, but it is not a diamond.
								</p>
							</div>
                          </div>
                        </div>
						
						<div class="card">
                          <div class="card-header" id="headingFive">
                              <a data-toggle="collapse" data-target="#collapse6" aria-expanded="false" aria-controls="collapseFive">
                           Can granite chip?
                              </a>
                          </div>
                          <div id="collapse6" class="collapse" aria-labelledby="headingFive" data-parent="#accordion-2">
                            <div class="card-body">
                              <p>
							Granite will not chip under normal use, although a heavy object hitting a square countertop edge could chip out a small bit of granite. If this should occur, the chip can be filled.
								</p>
							</div>
                          </div>
                        </div>
						
						<div class="card">
                          <div class="card-header" id="headingFive">
                              <a data-toggle="collapse" data-target="#collapse7" aria-expanded="false" aria-controls="collapseFive">
                          Are your Bench Tops manufactured in New Zealand?
                              </a>
                          </div>
                          <div id="collapse7" class="collapse" aria-labelledby="headingFive" data-parent="#accordion-2">
                            <div class="card-body">
                              <p>
							All of our Bench Tops are cut and manufactured in the NZ in our own dedicated manufacturing facility. This ensures that we maintain our high quality standards and exceptional level of customer service. Also enabling us to complete the installation of the granite worktops within 5-10 working days from templating.
								</p>
							</div>
                          </div>
                        </div>
						
						<div class="card">
                          <div class="card-header" id="headingFive">
                              <a data-toggle="collapse" data-target="#collapse8" aria-expanded="false" aria-controls="collapseFive">
                         Why are customers encouraged to view their slabs prior to fabrication?
                              </a>
                          </div>
                          <div id="collapse8" class="collapse" aria-labelledby="headingFive" data-parent="#accordion-2">
                            <div class="card-body">
                              <p>
							The beauty & elegance of granite is a result of its natural origins, most will contain colour variations, natural surface marks and blemishes. The veining and colour may vary slightly within the same slab even though your selected slab(s) may have been cut from the same raw block. These variations are to be expected and add to the unique character and natural beauty of the installation in your home or work environment.
								</p>
							</div>
                          </div>
                        </div>
						
						<div class="card">
                          <div class="card-header" id="headingFive">
                              <a data-toggle="collapse" data-target="#collapse9" aria-expanded="false" aria-controls="collapseFive">
                         Can we get any colours not available at Granite Tops?
                              </a>
                          </div>
                          <div id="collapse9" class="collapse" aria-labelledby="headingFive" data-parent="#accordion-2">
                            <div class="card-body">
                              <p>
							Our standard and expanded inventory colour selections represent the most popular design colours. Granite Tops maintains a constant inventory of our standard colors so that any project - large or small - can be fulfilled quickly from available inventory. There are new stone types being discovered and imported every month, just ask us if you need any particular so that we can try and source that for you.
								</p>
							</div>
                          </div>
                        </div>
						
						<div class="card">
                          <div class="card-header" id="headingFive">
                              <a data-toggle="collapse" data-target="#collapse10" aria-expanded="false" aria-controls="collapseFive">
                        Do you offer other types of finished edges?
                              </a>
                          </div>
                          <div id="collapse10" class="collapse" aria-labelledby="headingFive" data-parent="#accordion-2">
                            <div class="card-body">
                              <p>
						Our standard finished edge profile included in all base pricing is a basic polished straight edge. The straight edge profile maximizes the bold appearance and quality of 30mm thick material. We offer other edge profiles for a nominal charge - depending on the shape and finishing time required. Our other available edge profiles are viewable by clicking the "Edge Treatments" tab on the top of the home.
								</p>
							</div>
                          </div>
                        </div>
						
						<div class="card">
                          <div class="card-header" id="headingFive">
                              <a data-toggle="collapse" data-target="#collapse11" aria-expanded="false" aria-controls="collapseFive">
                       Will my granite Bench Top have visible seams?
                              </a>
                          </div>
                          <div id="collapse11" class="collapse" aria-labelledby="headingFive" data-parent="#accordion-2">
                            <div class="card-body">
                              <p>
						Most granite installations will require at least one or more joints called seams. During layout and design, we will always try to minimise the number of seams required. Additionally, when seams are necessary, we will locate them in areas of less traffic to minimise their appearance.
								</p>
							</div>
                          </div>
                        </div>
						
						<div class="card">
                          <div class="card-header" id="headingFive">
                              <a data-toggle="collapse" data-target="#collapse12" aria-expanded="false" aria-controls="collapseFive">
                      How much will my Bench Top cost?
                              </a>
                          </div>
                          <div id="collapse12" class="collapse" aria-labelledby="headingFive" data-parent="#accordion-2">
                            <div class="card-body">
                              <p>
						The exact cost will depend on the size of your kitchen, the type of worktop you’ve chosen and the extra details such as edging and upstands. We will provide a written quotation for you to agree before we commence any work. For a rough estimate, why not contact us.
								</p>
							</div>
                          </div>
                        </div>
						
						<div class="card">
                          <div class="card-header" id="headingFive">
                              <a data-toggle="collapse" data-target="#collapse13" aria-expanded="false" aria-controls="collapseFive">
                     Can I fit the Bench Top myself?
                              </a>
                          </div>
                          <div id="collapse13" class="collapse" aria-labelledby="headingFive" data-parent="#accordion-2">
                            <div class="card-body">
                              <p>
						Natural stone Bench Tops are very heavy and fitting it takes skill and experience. We strongly advise you to use our professional fitting service. We employee only fully-trained, professional fitters and do not use sub-contractors
								</p>
							</div>
                          </div>
                        </div>
						
						<div class="card">
                          <div class="card-header" id="headingFive">
                              <a data-toggle="collapse" data-target="#collapse14" aria-expanded="false" aria-controls="collapseFive">
                   I need further advice, can you help?
                              </a>
                          </div>
                          <div id="collapse14" class="collapse" aria-labelledby="headingFive" data-parent="#accordion-2">
                            <div class="card-body">
                              <p>
						Certainly, you can call us between 8am and 5pm Monday to Friday. You can also get in touch using our contact form and we'll get back to you as soon as we can.
								</p>
							</div>
                          </div>
                        </div>
						
						<div class="card">
                          <div class="card-header" id="headingFive">
                              <a data-toggle="collapse" data-target="#collapse15" aria-expanded="false" aria-controls="collapseFive">
                  My little sample of granite has pits on the surface – will I have these on my kitchen benchtops?
                              </a>
                          </div>
                          <div id="collapse15" class="collapse" aria-labelledby="headingFive" data-parent="#accordion-2">
                            <div class="card-body">
                              <p>
						Granite, which is crystalline in structure, always has tiny pits – spaces between the various mineral crystals. You don’t see them on a larger piece because the overall appearance is polished and mirror-like. Granite sometimes has natural fissures as well, which may look like cracks, but are not structural defects and are a naturally occurring result of the immense heat and pressure which formed the granite. These characteristics are part of the natural beauty of stone and will not impair the function or durability of the material. A product of nature cannot be expected to look man-made.
								</p>
							</div>
                          </div>
                        </div>
						
						<div class="card">
                          <div class="card-header" id="headingFive">
                              <a data-toggle="collapse" data-target="#collapse16" aria-expanded="false" aria-controls="collapseFive">
                 How do I place an order?
                              </a>
                          </div>
                          <div id="collapse16" class="collapse" aria-labelledby="headingFive" data-parent="#accordion-2">
                            <div class="card-body">
                              <p>
						Once you are happy with the quote submit your details by fax your order. A member of staff will be in contact with you to confirm the order and arrange for templating.
								</p>
							</div>
                          </div>
                        </div>
						
						<div class="card">
                          <div class="card-header" id="headingFive">
                              <a data-toggle="collapse" data-target="#collapse17" aria-expanded="false" aria-controls="collapseFive">
                 How can I get a quote?
                              </a>
                          </div>
                          <div id="collapse17" class="collapse" aria-labelledby="headingFive" data-parent="#accordion-2">
                            <div class="card-body">
                              <p>
						<a href="contact-us.html">Simply fax your kitchen plan with your contact details and we will be happy to give you a quote.</a>
								</p>
							</div>
                          </div>
                        </div>
						
						
                      </div>
                  </div>
                </div>
                
				<div class="col-12 mt-md-4">
                  <div class="faq-accordion">
                      <div class="faq-heading">
                       Payment
                      </div>
                      <div id="accordion-3">
                        <div class="card">
                          <div class="card-header" id="headingOne">
                              <a data-toggle="collapse" data-target="#collapse11" aria-expanded="true" aria-controls="collapseOne">
                               What payment methods do you accept?
                              </a>
                          </div>
                          <div id="collapse11" class="collapse show" aria-labelledby="headingOne" data-parent="#accordion-3">
                            <div class="card-body">
                              <p>We accept Cheques, Bankers Draft, Cash and Direct Credit. Please note the balance due on the installation day can only be paid by cheque or cash.</p>
                            </div>
                          </div>
                        </div>
                        <div class="card">
                          <div class="card-header" id="headingTwo">
                              <a data-toggle="collapse" data-target="#collapse22" aria-expanded="false" aria-controls="collapseTwo">
                                When do I Pay?
                              </a>
                          </div>
                          <div id="collapse22" class="collapse" aria-labelledby="headingTwo" data-parent="#accordion-3">
                            <div class="card-body">
                              <p>An Initial deposit of 50% is required once you place the order. A Further 50 % balance is due on the day we complete the installation.
                            </p></div>
                          </div>
                        </div>                        
                      </div>
                  </div>
                </div> 

	<div class="col-12 mt-md-4">
                  <div class="faq-accordion">
                      <div class="faq-heading">
                       Granite Engineered Stone Care 
                      </div>
                      <div id="accordion-4">
                        <div class="card">
                          <div class="card-header" id="headingOne">
                              <a data-toggle="collapse" data-target="#collapse111" aria-expanded="true" aria-controls="collapseOne">
                               How do I maintain Engineered Stone's natural beauty?
                              </a>
                          </div>
                          <div id="collapse111" class="collapse show" aria-labelledby="headingOne" data-parent="#accordion-4">
                            <div class="card-body">
                              <p>Simply wipe with warm water and soap, using a damp cloth or paper towel. There is no need to worry about grease, grime, hairspray, or messy makeup spills - Simply wipe it off! Engineered Stone is easy to care for and naturally maintains its luster for many years to come.</p>
                            </div>
                          </div>
                        </div>
                        <div class="card">
                          <div class="card-header" id="headingTwo">
                              <a data-toggle="collapse" data-target="#collapse222" aria-expanded="false" aria-controls="collapseTwo">
                              How should I remove stubborn or dried spills?
                              </a>
                          </div>
                          <div id="collapse222" class="collapse" aria-labelledby="headingTwo" data-parent="#accordion-4">
                            <div class="card-body">
                              <p>Use a damp, soft cloth with warm water and soap. If needed, apply common, non-abrasive, household cleaners. To avoid dulling the surface's shine, make sure to use a non-abrasive cleaner. To remove adhered material such as food, gum, nail polish or even dried paint, first scrape away the excess material with a plastic putty knife and then clean the surface with a damp cloth to remove any marks left behind and any residual dirt.
                            </p>							
							</div>
                          </div>
                        </div>
                        <div class="card">
                          <div class="card-header" id="headingThree">
                              <a data-toggle="collapse" data-target="#collapse333" aria-expanded="false" aria-controls="collapseThree">
                              How durable is Engineered Stone?
                              </a>
                          </div>
                          <div id="collapse333" class="collapse" aria-labelledby="headingThree" data-parent="#accordion-4">
                            <div class="card-body">
                              <ul class="listing">
								<li>Engineered Stone is resistant to cracks, chips, scratches and stains. However, like most materials, excessive force and/or pressure from objects can damage the surface.</li>
<li>Engineered Stone is resistant to most stains caused by fruit juices, liquid food coloring, coffee, tea, wine, grapes and soft drinks.</li>
<li>Engineered Stone's non-porous nature provides maximum resistance to staining and fully eliminates the need for any sealing. The non-porous quality of the surface also greatly reduces the potential for bacterial growth.</li>
								</ul></div>
                          </div>
                        </div>
						<div class="card">
                          <div class="card-header" id="headingFour">
                              <a data-toggle="collapse" data-target="#collapse444" aria-expanded="false" aria-controls="collapseThree">
                             Do I need to apply a sealer to Engineered Stone?
                              </a>
                          </div>
                          <div id="collapse444" class="collapse" aria-labelledby="headingFour" data-parent="#accordion-4">
                            <div class="card-body">
                              <p>
								No. Engineered Stone is a non-porous surface, so you will never have to apply sealer to any Engineered Stone surface.
								</p>
							</div>
                          </div>
                        </div>
						
						<div class="card">
                          <div class="card-header" id="headingFive">
                              <a data-toggle="collapse" data-target="#collapse555" aria-expanded="false" aria-controls="collapseFive">
                           Can I cut on my Engineered Stone countertop?
                              </a>
                          </div>
                          <div id="collapse555" class="collapse" aria-labelledby="headingFive" data-parent="#accordion-4">
                            <div class="card-body">
                              <p>
								Engineered Stone is composed 93% natural quartz, providing it with superior strength and beauty. Although your fine cutlery will not harm Engineered Stone, using a cutting board is recommended to prevent dulling the surface.
								</p>
							</div>
                          </div>
                        </div>
						
						<div class="card">
                          <div class="card-header" id="headingFive">
                              <a data-toggle="collapse" data-target="#collapse666" aria-expanded="false" aria-controls="collapseFive">
                          How do I maintain the polish on my Engineered Stone countertop?
                              </a>
                          </div>
                          <div id="collapse666" class="collapse" aria-labelledby="headingFive" data-parent="#accordion-4">
                            <div class="card-body">
                              <p>
							Polished: Due to its high density and non-porous qualities, normal cleaning with a damp cloth will keep your Engineered Stone surface looking like the first day it was installed. To avoid dulling the surface's shine, make sure to use a non-abrasive cleaner.
								</p>
							</div>
                          </div>
                        </div>
						
						<div class="card">
                          <div class="card-header" id="headingFive">
                              <a data-toggle="collapse" data-target="#collapse777" aria-expanded="false" aria-controls="collapseFive">
                         How does Engineered Stone withstand heat?
                              </a>
                          </div>
                          <div id="collapse777" class="collapse" aria-labelledby="headingFive" data-parent="#accordion-4">
                            <div class="card-body">
                              <p>
							Engineered Stone is structurally more heat resistant in comparison to other stones, including granite. However, any stone material can potentially be damaged by sudden and rapid temperature changes, especially near the edges. Therefore, using inexpensive and readily available hot pads or trivets is always recommended, especially when using cooking units such as electric frying pans, crock pots, or roaster ovens. Although Engineered Stone is not affected by heat below 300°F, it is advised that hot pans not be placed directly on the material.
								</p>
							</div>
                          </div>
                        </div>
						
						<div class="card">
                          <div class="card-header" id="headingFive">
                              <a data-toggle="collapse" data-target="#collapse888" aria-expanded="false" aria-controls="collapseFive">
                        Are there any chemicals or cleaners to avoid using?
                              </a>
                          </div>
                          <div id="collapse888" class="collapse" aria-labelledby="headingFive" data-parent="#accordion-4">
                            <div class="card-body">
                              <p>
							Avoid exposing Engineered Stone to chemicals with high alkaline or PH level, such as oven grill cleaners, floor strippers, toilet bowl cleaners, oil soaps, tarnish removers, furniture cleaners and drain products.
								</p>
							</div>
                          </div>
                        </div>
						
						<div class="card">
                          <div class="card-header" id="headingFive">
                              <a data-toggle="collapse" data-target="#collapse999" aria-expanded="false" aria-controls="collapseFive">
                         Is caring for my Engineered Stone surface really this easy?
                              </a>
                          </div>
                          <div id="collapse999" class="collapse" aria-labelledby="headingFive" data-parent="#accordion-4">
                            <div class="card-body">
                              <p>
							Engineered Stone's care-free maintenance and everlasting benefits and performance allows more time for the things that matter most to you. Whether you selected Engineered Stone to be your surface of choice for food preparation or to simply beautify your home, you can enjoy the peace of mind knowing that Engineered Stone is completely worry and care-free.
								</p>
							</div>
                          </div>
                        </div>
						
					
                      </div>
                  </div>
                </div>
                
				
		</div>
		
		
	</div>
</section>
<!-- About Section End --> 


<!-- Footer Include File -->
<?php include 'footer.php'; ?>
<!-- Footer Include File end -->