<!-- Header Include File -->
<?php include 'header.php'; ?>
<!-- Header Include File end -->


<!-- Breadcumb Section Start -->
<section class="breadcumb-wrapper">
		<div class="container">
			<div class="row">
				<div class="col-12">
					<h2>Porcelain</h2>
				</div>
			</div>
		</div>
</section>
<!-- Breadcumb Section End -->

<!-- Product Section --> 
<section class="section-padding">
	<div class="container">
		<div class="row">
			<div class="col-12 mb-4 mb-md-5">
				<div class="section-title text-center">
					<h3>Welcome to Our Products</h3>
					<h1>Porcelain</h1>
				</div>
			</div>
			<div class="col-12 col-md-12 col-lg-6 order-lg-2 pl-lg-5">
				<p class="descripton">Ascale Surfaces are the result of revolutionary technological advances in the production of ceramic and & porcelain products. These technological advances allow Ascale to reproduce the natural sintering process of metamorphic rock, which takes thousands of years, in a matter of minutes. Ascale combines 100% all natural minerals and sinters these minerals under extreme pressure and heat. <br><br>

As a result, Ascale is a sintered porcelain surface with technological advantages not found in other natural or engineered stone surfaces. Making Ascale the ideal product for endless interior and exterior, horizontal and vertical design and architectural applications.
</p>
			</div>
			<div class="col-12 col-md-12 col-lg-6 order-lg-1 mt-4 mt-lg-0">
				<div class="row">
					<div class="col-12 col-md-6 col-lg-6 gallery-coloum">
						<div class="gallery-wrap service-item">
							 <a href="assets/images/porcelain/bahia-silver.jpg" data-lightbox="image-1">
								<div class="image-container">
								   <img src="assets/images/porcelain/bahia-silver.jpg" class="img-fluid d-block mx-auto">
								</div>
							 </a>					 
						</div>
					</div>
					<div class="col-12 col-md-6 col-lg-6 gallery-coloum">
						<div class="gallery-wrap service-item">
							 <a href="assets/images/porcelain/belvedere-black.jpg" data-lightbox="image-1">
								<div class="image-container">
								   <img src="assets/images/porcelain/belvedere-black.jpg" class="img-fluid d-block mx-auto">
								</div>
							 </a>					 
						</div>
					</div>
					<div class="col-12 col-md-6 col-lg-6 gallery-coloum">
						<div class="gallery-wrap service-item">
							 <a href="assets/images/porcelain/cardoso-grey.jpg" data-lightbox="image-1">
								<div class="image-container">
								   <img src="assets/images/porcelain/cardoso-grey.jpg" class="img-fluid d-block mx-auto">
								</div>
							 </a>					 
						</div>
					</div>
					<div class="col-12 col-md-6 col-lg-6 gallery-coloum">
						<div class="gallery-wrap service-item">
							 <a href="assets/images/porcelain/cosmopolita-silver.jpg" data-lightbox="image-1">
								<div class="image-container">
								   <img src="assets/images/porcelain/cosmopolita-silver.jpg" class="img-fluid d-block mx-auto">
								</div>
							 </a>					 
						</div>
					</div>

				</div>
			</div>			
		</div>
		<div class="row mt-4">
			<div class="col-12">
				<p class="descripton">Why choose ASCALE countertops?<br><br>

				We have summarized the qualities of ASCALE that make your worktop unique.<br><br>

				They will allow you to get the best out of all of the foods you prepare, facilitating all your creations in the kitchen.<br><br>

				<ul class="listing-style">
					<li><Strong>Recyclable</strong>, to guarantee sustainability.</li>
					<li><Strong>100% natural</strong>, so you will not have to worry about contact with food on the surface.</li>
					<li><Strong>A lightness</strong> that is transmitted to the work environment.</li>
					<li>Made entirely in the <Strong>European Union</strong>, with the quality guarantee that it entails.</li>
					<li><Strong>Anti bacteria</strong>, for the perfect handling of all products.</li>
					<li><Strong>Non-absorbent</strong>, to avoid transmission of flavors and facilitate cleaning.</li>
					<li><Strong>Resistant to stains</strong>, they prevent them from becoming fixed.</li>
					<li>Perfect to withstand <Strong>high temperatures.</strong></li>
					<li>Its resistance is not impaired with <Strong>low temperatures.</strong></li>
					<li><Strong>Resists abrasion</strong>, cuts and scratches; its surface remains unchanged.</li>
					<li><Strong>Great size.</strong></li>
					<li>Its <Strong>durability is guaranteed</strong> by its high resistance.</li>
				</ul>
				<br><br>
				ASCALE countertops are the perfect surface for your kitchen work area. They combine with your own skill as a chef and enhance your creativity.</p>
			</div>
		</div>
		<div class="row mt-4 mt-lg-5">
			<div class="col-12 col-md-6 col-lg-3 gallery-coloum">
				<div class="gallery-wrap service-item">
					 <a href="assets/images/porcelain/crotone-pulpis.jpg" data-lightbox="image-1">
						<div class="image-container">
						   <img src="assets/images/porcelain/crotone-pulpis.jpg" class="img-fluid d-block mx-auto">
						</div>						
					 </a>
					<div class="gallery-title">Crotone Pulpis</div>	
				</div>
			</div>
			<div class="col-12 col-md-6 col-lg-3 gallery-coloum">
				<div class="gallery-wrap service-item">
					 <a href="assets/images/porcelain/grassi-white.png" data-lightbox="image-1">
						<div class="image-container">
						   <img src="assets/images/porcelain/grassi-white.png" class="img-fluid d-block mx-auto">
						</div>
					 </a>
					<div class="gallery-title">Grassi White</div>		
				</div>
			</div>
			<div class="col-12 col-md-6 col-lg-3 gallery-coloum">
				<div class="gallery-wrap service-item">
					 <a href="assets/images/porcelain/grum-black.jpg" data-lightbox="image-1">
						<div class="image-container">
						   <img src="assets/images/porcelain/grum-black.jpg" class="img-fluid d-block mx-auto">
						</div>
					 </a>
					<div class="gallery-title">Grum Black</div>		
				</div>
			</div>
			<div class="col-12 col-md-6 col-lg-3 gallery-coloum">
				<div class="gallery-wrap service-item">
					 <a href="assets/images/porcelain/imperia-silver.jpg" data-lightbox="image-1">
						<div class="image-container">
						   <img src="assets/images/porcelain/imperia-silver.jpg" class="img-fluid d-block mx-auto">
						</div>
					 </a>	
					<div class="gallery-title">Imperia Silver</div>		
				</div>
			</div>
			<div class="col-12 col-md-6 col-lg-3 gallery-coloum">
				<div class="gallery-wrap service-item">
					 <a href="assets/images/porcelain/moma-rusteel.jpg" data-lightbox="image-1">
						<div class="image-container">
						   <img src="assets/images/porcelain/moma-rusteel.jpg" class="img-fluid d-block mx-auto">
						</div>
					 </a>	
					<div class="gallery-title">Moma Rusteel</div>		
				</div>
			</div>
			<div class="col-12 col-md-6 col-lg-3 gallery-coloum">
				<div class="gallery-wrap service-item">
					 <a href="assets/images/porcelain/monteclemo-black.jpg" data-lightbox="image-1">
						<div class="image-container">
						   <img src="assets/images/porcelain/monteclemo-black.jpg" class="img-fluid d-block mx-auto">
						</div>
					 </a>
					<div class="gallery-title">Monteclemo Black</div>		
				</div>
			</div>
			<div class="col-12 col-md-6 col-lg-3 gallery-coloum">
				<div class="gallery-wrap service-item">
					 <a href="assets/images/porcelain/torano-statuario.jpg" data-lightbox="image-1">
						<div class="image-container">
						   <img src="assets/images/porcelain/torano-statuario.jpg" class="img-fluid d-block mx-auto">
						</div>
					 </a>
					<div class="gallery-title">Torano Statuario</div>		
				</div>
			</div>	
			<div class="col-12 col-md-6 col-lg-3 gallery-coloum">
				<div class="gallery-wrap service-item">
					 <a href="assets/images/porcelain/vagli-gold.jpg" data-lightbox="image-1">
						<div class="image-container">
						   <img src="assets/images/porcelain/vagli-gold.jpg" class="img-fluid d-block mx-auto">
						</div>
					 </a>
					<div class="gallery-title">Vagli Gold</div>		
				</div>
			</div>		
		</div>
	</div>
</section>
<!-- Product Section End --> 

<!-- Footer Include File -->
<?php include 'footer.php'; ?>
<!-- Footer Include File end -->