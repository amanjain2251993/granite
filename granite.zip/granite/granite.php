<!-- Header Include File -->
<?php include 'header.php'; ?>
<!-- Header Include File end -->

<!-- Breadcumb Section Start -->
<section class="breadcumb-wrapper">
		<div class="container">
			<div class="row">
				<div class="col-12">
					<h2>Granite</h2>
				</div>
			</div>
		</div>
</section>
<!-- Breadcumb Section End -->

<!-- Product Section --> 
<section class="section-padding">
	<div class="container">
		<div class="row">
			<div class="col-12 mb-4 mb-md-5">
				<div class="section-title text-center">
					<h3>Welcome to Our Products</h3>
					<h1>Granite</h1>
				</div>
			</div>
			<div class="col-12 col-md-12 col-lg-6 order-lg-2 pl-lg-5">
				<p class="descripton">Granite as Countertop or Vanity top has set the standard for durability, a sense of permanence, and outright aesthetic value. <br><br>For busy modern living, a granite countertop or granite vanity top delivers on a high-level of functionality. Granite is naturally resistant to the types of wear and tear a Countertop or Vanity top is likely to endure on a daily basis. <br><br>Heat resistance, abrasion resistance to cutlery and other common kitchen items, as well as moisture resistance are all areas where granite excels.</p>
			</div>
			<div class="col-12 col-md-12 col-lg-6 order-lg-1 mt-4 mt-lg-0">
				<div class="row">
					<div class="col-12 col-md-6 col-lg-6 gallery-coloum">
						<div class="gallery-wrap service-item">
							 <a href="assets/images/granite/amazon.jpg" data-lightbox="image-1">
								<div class="image-container">
								   <img src="assets/images/granite/amazon.jpg" class="img-fluid d-block mx-auto">
								</div>
							 </a>					 
						</div>
					</div>
					<div class="col-12 col-md-6 col-lg-6 gallery-coloum">
						<div class="gallery-wrap service-item">
							 <a href="assets/images/granite/antique-brown.jpg" data-lightbox="image-1">
								<div class="image-container">
								   <img src="assets/images/granite/antique-brown.jpg" class="img-fluid d-block mx-auto">
								</div>
							 </a>					 
						</div>
					</div>
					<div class="col-12 col-md-6 col-lg-6 gallery-coloum">
						<div class="gallery-wrap service-item">
							 <a href="assets/images/granite/atlantic-stone.jpg" data-lightbox="image-1">
								<div class="image-container">
								   <img src="assets/images/granite/atlantic-stone.jpg" class="img-fluid d-block mx-auto">
								</div>
							 </a>					 
						</div>
					</div>
					<div class="col-12 col-md-6 col-lg-6 gallery-coloum">
						<div class="gallery-wrap service-item">
							 <a href="assets/images/granite/avatar.jpg" data-lightbox="image-1">
								<div class="image-container">
								   <img src="assets/images/granite/avatar.jpg" class="img-fluid d-block mx-auto">
								</div>
							 </a>					 
						</div>
					</div>

				</div>
			</div>			
		</div>
		<div class="row mt-4">
			<div class="col-12">
				<p class="descripton">Being a natural material and created when the earth was formed, each granite slab features patterns and colours that make each Countertop or Vanity top one of a kind. <br><br>For a surface that offers a level of elegance that is often imitated but never seem to be able to measure up to Mother Nature, a granite Countertop or Vanity top is the surface by which all others are judged. Granite is coarse grained crystalline igneous rock composed primarily of quartz and feldspar. Granite is an elegant natural stone which has extraordinary range of colours and patterns. Each piece of granite displays color variations inherent in natural stone.<br><br> It is difficult to reproduce the actual color and depth of granite on the printed page. We suggest that final selections to be made from actual samples whenever possible.</p>
			</div>
		</div>
		<div class="row mt-4 mt-lg-5">
			<div class="col-12 col-md-6 col-lg-3 gallery-coloum">
				<div class="gallery-wrap service-item">
					 <a href="assets/images/granite/black-taurus.jpg" data-lightbox="image-1">
						<div class="image-container">
						   <img src="assets/images/granite/black-taurus.jpg" class="img-fluid d-block mx-auto">
						</div>						
					 </a>
					<div class="gallery-title">Black Taurus</div>	
				</div>
			</div>
			<div class="col-12 col-md-6 col-lg-3 gallery-coloum">
				<div class="gallery-wrap service-item">
					 <a href="assets/images/granite/golden-lightning.jpg" data-lightbox="image-1">
						<div class="image-container">
						   <img src="assets/images/granite/golden-lightning.jpg" class="img-fluid d-block mx-auto">
						</div>
					 </a>
					<div class="gallery-title">Golden Lightning</div>		
				</div>
			</div>
			<div class="col-12 col-md-6 col-lg-3 gallery-coloum">
				<div class="gallery-wrap service-item">
					 <a href="assets/images/granite/magma-gold.jpg" data-lightbox="image-1">
						<div class="image-container">
						   <img src="assets/images/granite/magma-gold.jpg" class="img-fluid d-block mx-auto">
						</div>
					 </a>
					<div class="gallery-title">Magma Gold</div>		
				</div>
			</div>
			<div class="col-12 col-md-6 col-lg-3 gallery-coloum">
				<div class="gallery-wrap service-item">
					 <a href="assets/images/granite/maritaca.jpg" data-lightbox="image-1">
						<div class="image-container">
						   <img src="assets/images/granite/maritaca.jpg" class="img-fluid d-block mx-auto">
						</div>
					 </a>	
					<div class="gallery-title">Maritaca</div>		
				</div>
			</div>
			<div class="col-12 col-md-6 col-lg-3 gallery-coloum">
				<div class="gallery-wrap service-item">
					 <a href="assets/images/granite/preto-agata.jpg" data-lightbox="image-1">
						<div class="image-container">
						   <img src="assets/images/granite/preto-agata.jpg" class="img-fluid d-block mx-auto">
						</div>
					 </a>	
					<div class="gallery-title">Preto Agata</div>		
				</div>
			</div>
			<div class="col-12 col-md-6 col-lg-3 gallery-coloum">
				<div class="gallery-wrap service-item">
					 <a href="assets/images/granite/river-white.jpg" data-lightbox="image-1">
						<div class="image-container">
						   <img src="assets/images/granite/river-white.jpg" class="img-fluid d-block mx-auto">
						</div>
					 </a>
					<div class="gallery-title">River White</div>		
				</div>
			</div>
			<div class="col-12 col-md-6 col-lg-3 gallery-coloum">
				<div class="gallery-wrap service-item">
					 <a href="assets/images/granite/titanium-black.jpg" data-lightbox="image-1">
						<div class="image-container">
						   <img src="assets/images/granite/titanium-black.jpg" class="img-fluid d-block mx-auto">
						</div>
					 </a>
					<div class="gallery-title">Titanium Black</div>		
				</div>
			</div>	
			<div class="col-12 col-md-6 col-lg-3 gallery-coloum">
				<div class="gallery-wrap service-item">
					 <a href="assets/images/granite/xisto-preto-titanius.jpg" data-lightbox="image-1">
						<div class="image-container">
						   <img src="assets/images/granite/xisto-preto-titanius.jpg" class="img-fluid d-block mx-auto">
						</div>
					 </a>
					<div class="gallery-title">Xisto Preto Titanius</div>		
				</div>
			</div>		
		</div>
	</div>
</section>
<!-- Product Section End --> 

<!-- Footer Include File -->
<?php include 'footer.php'; ?>
<!-- Footer Include File end -->