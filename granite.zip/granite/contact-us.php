<!-- Header Include File -->
<?php include 'header.php'; ?>
<!-- Header Include File end -->


<!-- Breadcumb Section Start -->
<section class="breadcumb-wrapper">
		<div class="container">
			<div class="row">
				<div class="col-12">
					<h2>Contact us</h2>
				</div>
			</div>
		</div>
</section>
<!-- Breadcumb Section End -->


<!-- Contact Us Section --> 
<section class="section-padding">
	<div class="container">
		<div class="row">
			<div class="col-12">
				<div class="section-title">
					<h3>Get Free Quote</h3>
					<h1>Let's work <span>together</span></h1>
				</div>
			</div>
			<div class="col-12 col-md-6 col-lg-6 mt-4 mt-md-5">
			
				<div class="form-wrapper form-style">
				<div id="error_message" class="ajax_response" style="float:left"></div>
				<div id="success_message" class="ajax_response" style="float:left"></div>
					<div id="frmContact">					
						<div class="form-group">						
							<input type="text" class="form-control" name="userName" id="userName" placeholder="Name">
							<span id="userName-info" class="info"></span>
						</div>
						<div class="form-group">
							<input type="email" class="form-control"  name="userEmail" id="userEmail" placeholder="E-mail">							
							<span id="userEmail-info" class="info"></span>
						</div>
						<div class="form-group">
							<input type="tel" class="form-control" name="subject" id="subject"  placeholder="Phone">
							<span id="subject-info" class="info"></span>
						</div>
						<div class="form-group">
							<textarea class="form-control" name="content" id="content" rows="4" placeholder="Your Message"></textarea>
							<span id="userMessage-info" class="info"></span>
						</div>
						<button type="submit" class="normal-btn m-red-btn d-block w-100" name="send" onClick="sendContact();">Send</button>
												
                    </div>
					
					</div>
				
			</div>
			<div class="col-12 col-md-6 col-lg-6 mt-4 mt-md-5">
				<div class="form-wrapper form-style">
						<div class="feature-box">
							<i class="fa fa-phone" aria-hidden="true"></i>
							<div class="content-wrapper">
								<h3 class="feature-title">06-368 6408</h3>
							</div>
						</div>
						<div class="feature-box">
							<i class="fa fa-envelope-o" aria-hidden="true"></i>
							<div class="content-wrapper">
								<h3 class="feature-title">info@granitetopsltd.co.nz</h3>
							</div>
						</div>
						<div class="feature-box">
							<i class="fa fa-home" aria-hidden="true"></i>
							<div class="content-wrapper">
								<h3 class="feature-title">27 Main Road South Levin <br class="d-none d-lg-block"> Horowhenua New Zealand - 5510</h3>
							</div>
						</div>
						<div class="mt-4">
							<iframe style="width:100%;height:375px;border:0 none" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3027.7399049317833!2d175.27039521543907!3d-40.635617608458965!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x6d40f34b497cee4b%3A0x5e2b66ca0ef63330!2s27+South+Rd%2C+Levin+5510%2C+New+Zealand!5e0!3m2!1sen!2sin!4v1464155314436"></iframe><br />
							<a href="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3027.7399049317833!2d175.27039521543907!3d-40.635617608458965!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x6d40f34b497cee4b%3A0x5e2b66ca0ef63330!2s27+South+Rd%2C+Levin+5510%2C+New+Zealand!5e0!3m2!1sen!2sin!4v1464155314436" target="_blank">View Larger Map</a>   
						</div>                      
				</div>
			</div>			
		</div>		
	</div>
</section>
<!-- Contact Us Section End --> 


<!-- Footer Include File -->
<?php include 'footer.php'; ?>
<!-- Footer Include File end -->